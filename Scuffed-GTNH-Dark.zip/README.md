# Scuffed-GTNH-Dark
GT New Horizons: Dark theme for 2.2.8

./designHelp/Gregtech.lang needs to be moved to the root of the modpack. It colors the gui-text appropriately.

## Texturing progress
| Mod                     | Number of textures | Progress |
|-------------------------|--------------------|----------|
| Minecraft               | 22/22              | 100%     |
| NotEnoughItems          | 5/5                | 100%     |
| Gregtech                | 157/??             | 95%      |
| Applied Energistics 2   | 38/38              | 100%     |
| ModularUI				  | 24/24			   | 100%     |

## Known issues
- Beacon UI seems to have graphical bugs even on vanilla texture (probably an Optifine issue)
